# Niagara Drift: decisions

The final decisions, dated, oldest first; a later one replaces an earlier one on the same thing. Add new ones
at the end. The current state is in the [README](../README.md) and the code.

## Project

- 2026-10-07: a fresh GitHub repo that keeps FoMni's git history (not a GitHub fork).
- 2026-10-07: PRs against `main`, never stacked on another PR's branch.
- 2026-10-11: the name is **Niagara Drift**; tagline "a drone synth for the M-VAVE FM-1". The folder
  (`~/fm1-drone`), the build files (`omni.*`) and the emulator's storage key keep their old names.
- 2026-10-11: Felucca is GPL-3.0-only (checked); code published under it stays usable.
- 2026-10-14: CLAUDE.md is kept out of the repo, because it's working notes, not for players.
- 2026-10-14: released as 0.1 beta (`./build.sh --release 0.1-beta`: identity FM-1_8000100). Over USB the
  FM-1 is "Niagara Drift FM-1"; the installers find it by "FM-1". FoMni's tags are renamed `fomni-v0.x`.
- 2026-10-14: the site is the emulator page at the root, with Install, Download, Full manual and Source
  (`tools/make_pages.py`). The web installer (`web/installer.html`) is English only: install, resume a cut-off
  install, put M-VAVE's V15 back (SHA-256 checked).

## The instrument

- 2026-10-09: **two drones**, DS-2-like (four voices was tried). KNOB 1-2 drone I, KNOB 3-4 drone II on every
  page, because four voices needed too much menu diving. Page buttons: tap to stay, hold to peek.
- 2026-10-07: pitch is set by knobs, continuous, because drones are tuned by ear between notes: 60 cents a detent (20 a turn = an octave), SEL held 1 cent.
  Each detent glides over the time since the last (up to 600 ms). Range 27 Hz .. 1.6 kHz.
- 2026-10-14: the pitch knobs speed up to 2x when spun (4x went too far); the other knobs to 4x.
- 2026-10-10: the starting sound: drone I D3, drone II A3, cutoff 70 / 68, resonance 35, partner detune 12, because an
  octave lower most of it sat under 200 Hz, which small speakers barely play.
- 2026-10-07: X-WAVE blends sine, triangle, saw, square (phase-aligned, snapping to a pure wave within 2/300).
  OSC MIX crossfades the oscillators and the sub.
- 2026-10-10: the sub: -1 oct, -2 oct, 1/3, 1/5; under 20 Hz it goes up an octave, since it can't be heard there. Just tuning for the
  partner's intervals (Setup 2).
- 2026-10-07: the filter is a 12 dB trapezoidal SVF (LP, BP, HP) that can self-oscillate. 2026-10-10: in
  low-pass the passband stays level at high resonance, so resonance never thins the bass. Cutoff and resonance run 0..1000 (a detent 10, SEL 1),
  shown as 0..100 with a tenth.
- 2026-10-09: links: hard sync (band-limited, polyBLEP), pitch link (KNOB 3 moves the offset), cross-mod
  (drone I's sound moves drone II's cutoff at audio rate) on the lone black key.
- 2026-10-11: NOISE per drone, a level beside the oscillators on Tone 2: 100 is 6 dB under them, 50 -12,
  25 -18, so it's heard all along the knob and never drowns the oscillators. Colour white or pink (-3 dB/oct), crossfading over the Morph; about equally loud.
- 2026-10-11: DRIFT: pitch drift plus four slow wanders per drone (cutoff +-0.5 oct, X-WAVE +-0.12, level
  +-2.4 dB, detune +-10 cents at 100), a new aim every 10..40 s glided over ~8 s.
- 2026-10-11: CHARACTER: softening from 8 kHz to 1.2 kHz in even steps, even harmonics, about +-6 cents of
  jitter, drone II up to 6 cents sharp, -44 dB noise; skipped at 0.
- 2026-10-14: FEEDBACK: the finished sound fed back into both drones' filters, 256 samples later, lows cut at
  80 Hz; loop gain 0.9 at 100, its addition capped at 0.45, so it adds texture without running away or getting
  louder.
- 2026-10-10: MASTER: a square law up to 4/5 of the turn (the clean top), then drive to full, so the top of the
  knob is an effect, not just louder.
- 2026-10-10: every continuous setting glides in the engine (a knob detent over the time since the last), so slow
  turns sweep instead of stepping.

## Movement

- 2026-10-07: the Ultra LFO: one rate, two taps (Wave I, Wave II) of Off + 7 shapes + random, routed per drone
  to pitch or X-WAVE and to cutoff or resonance, with bipolar depths. 2026-10-14: rate 0.02 Hz (a cycle in 50 s,
  the DS-2's slowest) .. 70 Hz; longer arcs come from Scene switch and the motion loop.
- 2026-11-07: the defaults review (Evan, item 9): the FM-1's own times for a new FM-1, Fade 1.5 s (29, was 0.99 s),
  Morph 2.0 s (34, was 0.63 s), Scene time 7.8 s (40, was 16 s: a player pressing a scene key also sees how far in it
  is); and the sound's Pitch glide 0.05 s (7, was off; Evan picked it of 0.05, 0.1 and 0.2 s by ear), so Wander's notes slide a little (every Preset that leaves it
  alone too). Everything else kept. The flash chips: fl_id_ok() (any standard SPI NOR of 1-16 MiB, since 0.2.1) in its
  own header with a host test: the Puya P25Q80 (856014) and the newer FM-1s' UC25HQ80 (B36014) both.
- 2026-11-07: Partner and Shift follow the Tuning (ledger item 8), as Wander and Chord since #63: on a Tuning other
  than 12-tone and Quarter a partner's interval is the Tuning's over its drone, from the interval's pure size
  ("+5th" and "+5th just" the same; the value shows the name alone); Shift's knob steps from note to note of the
  Tuning over drone I (SEL: a cent, off the notes), named by the nearest 12-tone interval ("+5th", "-4th", "+m3"; Evan:
  "700 -> 695 seems weird"), each drone moving as many notes from its own; a move off the notes stays exact cents.
  Drift stays (a wobble, not an interval). The word under a value at its units' size (13 px, as the "c" in "+503c";
  Evan: smaller, across the firmware).
- 2026-11-07: the LFO's slowest rate a cycle in 100 s (0.01 Hz, as the Sub 37's slowest; was 50 s), the top still
  70 Hz, the slow rates given most of the dial (Evan: a drone synth is about slow changes; then, on the FM-1, each
  second on the dial): 0..152, a click a second from 100 s to 10 s (v 0..90), then 62 steps of the same size (10 s to
  9 s, about 11 %) to 70 Hz; 26 s at 74, 1 Hz at 112. Saved sounds keep their rate at the nearest step (within 5 %).
- 2026-10-11: rate mod is linear (+-100 = +-3 octaves) and keeps the tempo; Random draws a new level at every
  restart, seeded at the first PLAY.
- 2026-10-11: PRESETS is Wave I, ALGORITHM is Wave II, SELECT is the LFO rate.
- 2026-10-11: OCT- / OCT+ step the MOVEMENT (octave jumps were too abrupt for drones): every LFO depth scaled 0..200 %, 10 % a tap, lit while off 100 %.
- 2026-10-11: the default sound breathes (filter LFO depth +25 on drone I, -25 on drone II), so the Movement is
  heard at once.
- 2026-10-10: the SWELL (code: Pulse) on ARP: tap on / off, hold to peek, two taps within 350 ms open its page.
  From 0.03 Hz (a 33 s breath); Shape firms a sine into a gate; Depth in dB (0 .. -30, 100 silence). It fades in
  and out over the Morph time like a breath (exponential), and ARP flashes with the beat.

## Switches, scenes and the loop

- 2026-10-11: the black keys: drone I (partner, sub, filter) | pitch lock, LFO reset | drone II | pitch link,
  hard sync | cross-mod. The LFO pages turn them into routing.
- 2026-10-10: MORPH: a switch never jumps (a jump clicks and breaks a drone); it moves the sound over the Morph
  time (0.02 .. 30 s). Stopped,
  everything snaps.
- 2026-10-09: 16 scenes on the white keys. Tap: go there over the Scene switch time (0.1 s .. 5 min) and stay.
  2026-10-11: hold: visit, and let go to come back. SAVE held + a key stores. The white keys are only scenes.
- 2026-10-11: scenes keep the sound, not the room: Fade, Tune, Speaker, Stereo, Pitch lock, Morph and Scene
  switch stay as they are, because they belong to where and how you play, not to the sound.
- 2026-10-14: the scene stored or recalled last blinks slowly until the sound is changed by hand, so you can see
  which one you're on.
- 2026-10-09: the MOTION LOOP on REC: knob moves recorded with their timing, up to 5 minutes (4096 events);
  each pass starts from where the recording began.
- 2026-10-11: SEL + PLAY fades drone II alone. Pitch lock guards only the pitch knobs.
- 2026-10-14: SAVE and storing a scene while playing write at once, the output dipped ~50 ms around it to hide the flash write's
  pause (under 6 ms). The
  autosave waits until PLAY stops.

## Effects

- 2026-10-09: a dark PT2399-style delay (70 .. 450 ms, repeats up to runaway) into a reverb of four types
  (Room, Plate, Hall, Chorus hall; Dattorro's plate structure, our own code), one mix each for both drones, the
  LFO on the delay's time. Mono-safe, because the FM-1 has one speaker. Defaults: reverb 25 % Hall, delay off.
- 2026-10-10: the SPEAKER low cut (40 .. 240 Hz), off by default, since headphones and line out don't need it.

## The screen

- 2026-10-09: concept D: dark and glowing; moving pictures on top, what's selected or moving below; live
  waveforms. 2026-10-10: no interval readout between the drones (tuned by ear).
- 2026-10-11: 13 pages, all full: Play 1 / 2, Tone 1 / 2, Osc, LFO depths / mods, Partner, Setup 1 / 2,
  Effects 1 / 2, Swell. The names match on screen, manual and README; "Scene switch" (was "Scene time").
- 2026-10-14: the text a quarter bigger (15 / 19 / 19 / 28 px), to read it on the device; a value too wide steps down a face.
- 2026-10-14: no FoMni splash; our startup animation fades in from black.

## Engineering

- 2026-10-07: the engine is `dsp/drone.{c,h}`; `drone_fx.c` is included by it.
- 2026-10-09: scenes live in the project (16 x every parameter); new parameters go at the end and bump
  PROJ_FORMAT (saved projects reset once).
- 2026-10-14: CPU on the FM-1: about 39 % with the default sound, 3.5 % stopped; the host estimate reads low
  (it misses divides), so measure on the device (`tools/fm1_cpu.py`).
- 2026-10-17: key pressure on the 20 lower keys (F3–C5; the top seven have no converter), ported from MONK-1. Absolute scale: 0 % at a light touch
  (reading 900), 100 % at a firm press (540), curve ^1.6, hysteresis 32. Shown on screen while held; nothing
  plays from it yet.

## v0.2

- 2026-10-17: OCT− / OCT+ play the LFO's Wave I / Wave II: a tap is the next shape, wrapping; SEL + OCT the one
  before; each lit while its wave is up. ALGORITHM is the Movement; PRESETS is kept for a macro.
- 2026-10-17: EDIT has Osc (X-Wave, PW) and Source (osc mix, drive); ENV has one page, Tone (noise, colour);
  Setup 2 is morph, scene switch, tune, tuning.
- 2026-10-17: the noise Colour is a blend, 0 white .. 100 pink (PROJ_FORMAT 20; a 0.1 project loads, its
  Colours turned into 0 or 100).
- 2026-10-17: lights have brightness levels (software PWM over 32 scan frames, the share lit the level squared);
  the OCT lights pulse with the LFO waves and the ARP light breathes with the Swell. The pressure test readout
  is gone (it covered the black keys' banners).
- 2026-10-17: turning an LFO depth that can't be heard shows why: "MOVEMENT 0% ALGORITHM", or "WAVE I OFF tap OCT-"
  (II and OCT+ likewise). The top bar's right-hand text (PLAY to start, FADING) shortens or hides where the
  badges on the left (II OUT) would overlap it.
- 2026-10-17: scenes are in banks: 12 a bank on the lower white keys (F3–C5, the keys that sense pressure);
  banks A, B, C are yours (A in the project object, B and C in their own at 0x97000 and 0x99000, above the
  app area the loader writes), and a read-only Presets bank is in the firmware (so far the starting sound and
  the bass test). SEL + D5 / E5 / F5 / G5 picks A / B / C / Presets; the top four keys alone are kept for the
  gesture macros. A 0.1 project's scenes 1–12 become A1–A12 and 13–16 B1–B4 (PROJ_FORMAT 21; the banks are
  written before the project, so a power cut can't lose them).
- 2026-10-17: scene switches and visits follow Pitch lock: lock on, the drones keep their pitch (and the link
  offset).
- 2026-10-17: backup and restore over USB (SysEx 0x70–0x73: read, write, commit an object; restart):
  `fm1_install.py --backup [FILE]`, `--restore FILE`, and a backup in `~/niagara-drift-backups/` before every
  install over Niagara Drift (`--no-backup`: not). The web installer's comes later.
- 2026-10-17: the pressure crossfade: a scene key held is a fader from the sound before into its scene; under 8 %
  nothing moves, 90 % is all the way, and held there 0.3 s the scene is taken (the key flashes). A tap (under
  0.25 s, however hard) goes there over the Scene switch time; letting go glides back over the Morph time
  (pressed again on the way, from there); SEL held at release keeps the blend. The key's brightness shows how
  far in. Where a key has no pressure (the emulator), a hold is 0.1's timed visit.
- 2026-10-17: LFO mods: a negative delay wobble reads "-+25%"; X-mod draws the range it pushes drone II's
  filter through.
- 2026-10-17: a value a hand moves while a scene switch (or a crossfade) is on its way is let go by the switch:
  the left encoders (LFO rate, Movement, the macro) and the OCT wave taps; the rest still lands. A page knob
  still stops the switch where it is. A new switch moves everything again.
- 2026-10-17: the drones' pictures start on a cycle, or after 0.1 s without one (hard sync could freeze
  drone II's).
- 2026-10-17: the macros: eight fixed moves, each a few settings by set amounts, added on top of the sound
  (the sound's own values untouched; what's heard is clamped to each range). Set macros Bloom, Weight, Tide,
  Tear on SEQ's Macros page (SEQ again: Partner); PRESETS plays one, Bloom to start, SEL + PRESETS picks
  (the player's choice, not a scene's). Gestures Beat, Heat, Converge, Wash on D5–G5: held they swell in, let
  go out; a tap latches, a press releases, SEL at release latches where it is; held, PRESETS sets the depth
  and ALGORITHM the swell (1–30 s). Tear switches hard sync on and lifts drone II up to an octave; Converge
  turns cross-mod on and leans drone II toward the nearest unison or octave of drone I. Amounts, depths,
  swells and latches are values scenes keep; with Pitch lock on a scene leaves Converge's latch alone.
  PROJ_FORMAT 22 (19–21 converted: their 78 values a sound widened, the new ones at their defaults).
- 2026-10-17: a new starting sound (also Preset P1), slow and breathing like the calm Lyra-8: filter LFO depths
  ±85 at LFO rate 8, Wave II a random glide, the Swell on (rate 6, depth 40), resonance 250, delay mix 25 with
  repeats 50 and a +20 wobble, reverb mix 35. Measured: a 16 dB loudness swing, 1.6 octaves of brightness, 95–99 %
  of the movement slower than 0.5 Hz (0.1's start: 3.7 dB, 0.7 octaves, ~42 %).
- 2026-10-17: a restart brings back every saved value (the engine's queue held 64 and dropped the rest of a
  load, so effects, Character, Feedback and the macros came back at their defaults); it holds 128 now.
- 2026-10-17: a save writes the project only when it differs from what's on the flash (the banks already were).
- 2026-10-18: the effects are ChoralRoot's design, written anew in float. The delay is stereo, with four types
  (each a mode, spread, tone and wow): Tape (mono, warm, gentle wow), Wide (the right at 3/4 of the left's time),
  Ping-pong, Clean (bright, no wow). The reverb is an eight-line feedback delay network at 22.05 kHz with four
  types (size, pre-delay, swing, low cut, width): Room, Hall, Cathedral, Chorus hall. FX: Delay (type, time,
  repeats, mix) / Reverb (type, length 0.3–40 s and Inf, damp, mix); a type change glides. Inf is a freeze
  (damping out of the loop); stopped, it lets go over about twice the Fade time. Wash adds +45 Length (Inf at
  full depth). Defaults: Tape, Length 60 (5.9 s), Damp 40.
- 2026-10-18: ENV has two pages: Tone 1 (noise, colour) and Tone 2 (character, feedback, speaker, pressure
  sensitivity x0.5–x2). Speaker and Pressure are room settings, not in scenes. PROJ_FORMAT 23 (22 converted).
- 2026-10-18: worst-case sound on the FM-1 (everything on, full feedback and character, all macros): 57 %
  average, 70 % peak block, no late blocks (0.1's effects). The new effects cost the same on the host.
- 2026-10-18: SEL held 0.4 s shows the black keys' map over the whole screen: the five groups as rows, each key lit
  as on the panel with its name and setting (the LFO pages' layer there); a turning knob or a held white key
  takes the screen back.
- 2026-10-18: during a crossfade, SEL down holds the blend where it is; letting go of the key then keeps it (a
  finger's pressure falls on the way up, which had carried the blend back first).
- 2026-10-18: the drones' pictures blend each new capture in over ~0.1 s.
- 2026-10-18: Play 2 is level, then resonance (KNOB 1 / 3 level, 2 / 4 resonance); its picture shows the level above
  the filter curve. Speaker and Pressure move from Tone 2 to a new GLO page, Setup 3; Tone 2 keeps character and
  feedback (KNOB 3-4 nothing).
- 2026-10-18: the screen takes the site's palette: plum black (20, 0, 15), aubergine panels, the site's card for a lit
  value, pale pink ink; amber drone I, teal drone II, lilac the LFO, everything else in the ink (no blue, pink or
  gold). All text 4.5:1 or more on its background. No dots: page dots become "1/3", the unsaved dot becomes a dim
  SAVE light, the LFO rate lights go (OCT- / OCT+ pulse), Setup 1's stereo dots become two bars. Barlow stays.
- 2026-10-18: the gestures (D5-G5) are Weight, Shift, Converge, Wash (Beat and Heat gone). Each macro's moves come in
  over their own part of its amount and leave over another (eased, gliding up to 0.6 s), so parts arrive in order.
  Shift: drone I then drone II to a 5th up (default), 4th up, 4th down or 5th down (PRESETS held). Converge pulls to
  the nearest unison, 4th, 5th or octave (at most 2.5 semitones), detune and Drift to 0, cross-mod last. Weight adds
  drive +30 and resonance -80. Wash adds Damp +15. Swells to start: Weight 45 (4.6 s), Shift 70 (11 s), Converge 60
  (7.7 s), Wash 55 (6.5 s). PROJ_FORMAT 24 (23's gesture values reset). The Macros page is unchanged for now.
- 2026-10-18 (Evan's listening): Weight focuses: Width, the partners' detune to 0 and Movement -25 over its first 60 %,
  cutoffs -100, the sub over 20-100 %. Converge: drone I dips (level -25, cutoff -60) while drone II moves (a bump, in
  over 0-20 %, out over 45-75 %, both ways). Wash: its release is 2.5x its swell; at the top (85-100 %) the dry levels
  breathe -14 at 0.15 Hz.
- 2026-10-18 (Evan's listening, round 3): Weight is a full, warm bass, not focused: osc mix +45 (0-70 %), cutoffs -30,
  resonance -40, drive +35, Character +25, noise -40, drone I's level +8; the width, detune and Movement moves are gone.
  Converge never quite converges: drone II stays 0.09 semitone short of the consonance, wavering by 0.05 at 0.07 Hz
  (about 1.3 beats a second at A3); the partners' detune and Drift ease by 60 %, not to 0.
- 2026-10-18: the gestures play by hold (in while held, out when let go) and tap (to its depth, stays; tap again: out);
  depth on PRESETS while held. Swells shorter: Weight 30 (2.8 s), Shift 40 (3.9 s), Converge 35 (3.3 s), Wash 35
  (3.3 s); letting go takes as long as the swell (Wash's 2.5x release gone; its tails are the reverb's own). PROJ_FORMAT
  25 (24's swells reset to these). Clean, when built, keeps the notes (no unison or sync).
- 2026-10-18: the player times the gestures (Evan: "not just on-off effects"). PRESETS is Macro time: every
  gesture's time x0.1 .. x10 (50: as set), live, kept in the project (not scenes; PROJ_FORMAT 26, in the byte that
  held the macro PRESETS played, which is gone). Let go after a hold: out over as long as it was held, x Macro time.
  Holding a gesture key: ALGORITHM its depth (Shift: its move), PRESETS its own time. A move's level glides over
  0.15 s at most (was 0.6).
- 2026-10-18: the set macros Bloom, Weight, Tide and Tear go (Evan). SEQ: Gestures (KNOB 1-4 each gesture key's depth;
  a key playing Shift: its move), Partner, Partner 2 (KNOB 3 Wander). Their four values become Wander, Age, Shift's
  move (from E5's depth) and one unused; PROJ_FORMAT 27 converts. Each gesture key plays what the player picks
  (hold it + SELECT): Weight, Shift, Converge, Wash, Clean, Glitch; kept in the project (gkey, not scenes), D5-G5 to
  start Weight, Shift, Converge, Wash. Clean: grit ZERO over 0-25 %, Movement -80 % / Drift -70 % / the Swell's
  depth over 10-55 %, repeats -70 % over 25-70 %, delay mix 0 / reverb mix -75 % / length -50 % over 30-100 %; cross-mod
  and hard sync held off; the notes kept. Glitch (Slip): delay mix +20, repeats +12, delay time wandering +-6 (a new
  aim every 1.5-4 s, followed over ~1 s; a third with a 150 ms snag of +0.4). Age (Tone 2 KNOB 3): cutoffs -70,
  noise +30, Character +35, a wow of +-14 cents a drone; wears in over 20 s. Wander: steps among 5th, 4th, octave
  (then 3rds, 6ths further up), placed nearest drone II's pitch, home about every other step, every (40 - 32 x
  amount) s x 0.6-1.4, gliding 3-5 s. Turning drone II's knobs on Play while it's out says "II OFF  SEL + PLAY".
- 2026-10-18 (Evan): Wander is a random melody: it jumps (GLO's Glide slides it) among a minor pentatonic on drone I
  (root, minor 3rd, 4th, 5th, minor 7th, any octave) within 7 + 5 x amount semitones of drone II's pitch, home with a
  chance of 0.12 a step, a note every (20 - 18.5 x amount) s x 0.5-1.5. Shift's move is continuous, in cents
  (0..1400, 700 none: a fifth down to a fifth up; a detent 10, SEL 1). SEQ adds Gestures 2: each key's own time.
  NOISE at 100 is level with the oscillators (was 6 dB under), as a Moog's mixer; PROJ_FORMAT 28 halves 27's noise
  values (the same level) and turns Shift's four moves into cents.
- 2026-10-18 (Evan): one way to play a gesture. The Gestures pages go, with each key's depth and time (P_GD_* and
  P_GR_* unused): a hold goes as far as you hold, a tap all the way (each gesture's full depth: Weight, Wash,
  Glitch 70, the others 100; its time: Weight 2.8 s, Shift 3.9 s, the others 3.3 s, x Macro time). A gesture key
  held: ALGORITHM is still Movement, PRESETS Macro time, SELECT what it plays. SEQ = Partner / Partner 2; Partner 2:
  KNOB 1 Shift's move, KNOB 3 Wander, KNOB 4 Wander's scale (P_WSCALE, the old unused slot 81; no format change):
  minor pentatonic, major pentatonic, fifths and octaves, whole tone, Dorian, just (harmonics 1-8: 0, 386, 702,
  969 cents). While a gesture is in, the LFO moving the same thing eases toward 0, as far as the move or the
  gesture is in: the oscillator LFO (routed to pitch) for Shift and Converge, the filter LFO (routed to what it
  moves) for cutoff or resonance moves, the delay LFO for the delay time.
- 2026-10-18 (Evan): Wash eases both filter LFOs' depths to a third (by 67 %, in over 20-70 % of its amount, out
  over 0-40 %): with Movement up their cutoff sweeps piled up in the reverb and delay as surges (Movement 100: 9.5
  -> 4.7 dB loudness swing, 2.6 -> 0.5 octaves brightness swing; at Movement 0 unchanged).
- 2026-10-18 (Evan): the gesture keys are fixed, so you learn where they are: D5 Weight, E5 Shift, F5 Clean, G5
  Wash; hold + SELECT picks nothing (SELECT is the LFO rate). Converge and Glitch are gone. A gesture key let go
  under 500 ms is a tap (was 250). SEQ's second page is **Moves** (was Partner 2). Wander's knob is how often: notes
  at random gaps from 25-30 s (1) to 0.5-2 s (100), log between; it reaches an octave either way. Wash moves the
  delay mix, repeats, reverb mix and length toward 70, 80, 80 and 100 (only up, never past the sound's own), so the
  repeats stay under the delay's howl (87). PROJ_FORMAT 29: 28's gesture latches let go.
- 2026-10-18 (Evan): GLO holds only the room's settings (none in a sound), on two pages: Setup 1 Fade, Morph, Scene
  switch; Setup 2 Tune, Stereo, Speaker, Pressure (Setup 3 gone). Glide moves to Moves KNOB 2, Drift to Tone 2 KNOB
  4. Tuning goes into each drone's Interval: 17 steps, each interval tempered then just (-Oct, -5th, -5th just, -4th,
  -4th just, Unison, +m3, +m3 just, +M3, +M3 just, +4th, +4th just, +5th, +5th just, +Oct, +Oct+5, +Oct+5 just);
  P_JUST unused. PROJ_FORMAT 30 folds 29's Tuning into each interval.
- 2026-10-18 (Evan): the Presets bank holds twelve sounds, P1 Niagara (the starting sound), P2 Deep, P3 Just fifths,
  P4 Glass, P5 Choir, P6 Wanderer, P7 Tape, P8 Pulse, P9 Howl, P10 Cathedral, P11 Metal, P12 Clean (one oscillator,
  everything off). Any but P12 can be saved over (OBJ_BANKP at 0x9B000; the firmware's comes back where none is
  saved); P12 is locked ("CLEAN IS LOCKED"). Levelled to P1 within about 2 dB (K-weighted). A new FM-1 starts on the
  Presets bank. The installer backs up the saved-over Presets too. SEL + a top key no longer latches that key's
  gesture as it's let go.
- 2026-10-18 (Evan): the Presets get more range: P2 Abyss, P3 Eerie, P5 Heaven replace Deep, Just fifths, Choir;
  P6-P11 redone. The drones sit a minor third, tritone, major tenth, minor seventh, whole tone, semitone, major sixth
  and an inharmonic gap apart; sines to squares, LP/BP/HP, subharmonic subs, Character 0-70, Feedback 0-85, resonance
  to 720; each its own reverb (Room, Hall, Cathedral, Chorus hall) and delay (Tape, Wide, Ping-pong, Clean; 70-450
  ms). P4 Glass kept. Levelled to P1 within about 3 dB (Abyss -3.3, Howl -3.8, the dark ones). Drone II out (SEL +
  PLAY) is a sound's value (P_II_OUT, Tuning's old slot): P12 Clean has it out, and turning drone II's knobs on any
  page says "II OFF  SEL + PLAY". A scene key let go under 500 ms is a tap (was 250), as a gesture key; the
  pressure crossfade still starts at 250 ms.
- 2026-10-18 (Evan): each Preset moves its own way with the LFOs (before, all shared the starting sound's cutoff
  sweep): Abyss the filter LFOs on resonance (+-55, rate 3); Eerie drone II's osc LFO on pitch (12) and rate mod 40
  by Wave I; Heaven the osc LFOs on X-Wave (65); Wanderer Wave I Roundtooth, rate 12, filter +-60; Tape osc LFO on
  both pitches (7, 6), rate 40 (a tape wow), filter +-40; Pulse the LFO locked to the Swell's bars, rate 35; Howl Wave
  I random steps on drone I's resonance (50), rate 20; Cathedral filter +-15, Movement 25; Metal osc LFOs on X-Wave
  (45), rate 45, filter +-50. A preset holds up to 40 changes.
- 2026-10-18 (Evan, after review 3): Shift and the 60-cent pitch step stay. Pitch lock stays off by default (it
  also locks the pitch knobs); most Presets put drone I on D (D2-D5) so moving between them keeps the root. P6
  Tanpura (Sa and Pa, plucked by the Swell) and P8 Whistle (self-oscillating filters at D5 and A5) replace Wanderer
  and Pulse. No sub under 40 Hz (Abyss and Cathedral a third's subharmonic of D3, 49 Hz; Tape an octave down).
  Presets levelled to P1 within about 2.4 dB A-weighted and through a 200 Hz high-pass (a small speaker); the screen
  names a Preset as it's chosen ("SCENE P3 EERIE"; not once it's saved over). Clean holds the loudness: the output's
  slow level (30 s while Clean is out, 3 s while in) eases down to match, as far as Clean is in, 12 dB at most.
- 2026-10-18 (from review 4, no design change): the top bar's badges (SWELL, VISIT, II OUT) show only where they fit
  beside the left-encoder pill; holding SAVE says "KEY: STORE  LET GO: SAVE"; the panel picture shows 12 scenes and
  the four gestures; the README says the drone-I / drone-II knob rule holds on the drone pages.
- 2026-10-18 (Evan, from review 4): two quick ARP taps open the Swell page without touching the Swell (a lone tap
  switches it 350 ms later); a page button opens the page last used there (HOME always Play 1); while SELECT,
  ALGORITHM or PRESETS turns, its name and value fill the values row, large (the top-bar pill is gone). PRESETS stays
  Macro time.
- 2026-10-19 (Evan, after trying #28 on the FM-1): Macro time is **Gesture time**. Pitch lock is on at start (the
  room's, not a scene's). The Presets are fixed (SAVE + a key there says "PRESETS ARE FIXED"); any saved over before
  move to the first empty slots of C, then B, then A. The sine and the triangle ~4 dB louder (x1.6, x1.7; the
  presets' and the starting sound's levels lowered to match: within 0.1 dB of before). Morph is **Key glide** (black
  keys, LFO waves); **Scene time** (default 46, ~4 s) is every scene move: a tap, a crossfade's glide (the pressure
  is where it heads, at most the whole way a Scene time), its way back. SEL during a crossfade holds it until the
  key lets go. OCT doesn't show the wave on LFO depths. The autosave waits 4 s after the last change (not only the
  last touch) and writes at most every 30 s (a long scene switch wrote 660 times in 20 s).
- 2026-10-19 (Evan): the SEL key map draws the 11 black keys where they sit (3-2-3-2-1), lit as the panel's, with
  only the groups named (I, BOTH, II, LINKS; on the LFO pages I, BOTH, II, DLY, XMOD). A black key touched while SEL
  is held names itself and its setting, large, and doesn't switch.
- 2026-10-20 (Evan, from review 4): pages renamed Tone 2 → **Life**, Source → **Sub · Drive**, Moves → **Pitch moves**,
  LFO mods → **Mods** (knobs unchanged). Age is the tape alone (darker, hiss, wow, and a flutter of ±4 cents at
  5.7 and 8.9 Hz), no longer adding Character (P7 Tape's Character 70 → 98). Card labels one size up (FONT_S), with
  Char., Feedbk, Press., Keys, R. mod, and Osc / Filter on LFO depths on the cards. The LFO key layer and SEL on the
  top keys stay. Fix: Age's wow no longer freezes once Age has worn in.
- 2026-10-20 (Evan): Key glide is **Switch time** ("black keys, LFO waves"; card "Switch"); Scene time's hint is
  "between scenes"; Glide is **Pitch glide** (card "Glide").
- 2026-10-20 (Evan, from review 3): the headphone jack is read (PB5: 1 speaker, 0 headphones; a plug settles for
  150 ms): the speaker always gets a fixed ~120 Hz low cut, headphones never do. The Speaker knob is gone (P_SPEAKER
  unused); Setup 2 is Tune, Stereo, Pressure (KNOB 3), KNOB 4 empty; no message on a plug. Weight: sub +15 (was 45),
  cutoffs -10 (was -30), drive +25 (was 35), both drones' levels +40 (was drone I +8): +1 dB on the speaker (was
  -2.4), +1.9 dB full range. The README says MASTER's top quarter flattens the breathing. Movement and the presets
  stay as they are.
- 2026-10-20 (the 0.2 QA pass): presets keep the pitch you're on while Pitch lock is on (Evan) and are levelled for
  that: within ±2.1 dB of P1 at D3/A3 (−3.4..+2.7 at their own pitches); the starting sound 3 dB quieter (levels 57 /
  37, were 80 / 52). MASTER's top fifth at the same loudness (the output down by the drive^0.72; six presets within
  ±2.3 dB, 0 on average; Evan). Feedback's loop is a multiple of drone I's period (256..510 samples, was 256), its
  gain at 100 0.7 (was 0.9), the loudness it adds taken off: ~+1 dB at 100 (was +5..7, ringing an F). Fixes: a kept
  gesture (SEL) no longer jumps; letting go of a gesture only brings things back; Wash breathes (55..70 %); the LFO's
  restart eases over 120 ms; Wander re-times when turned up; delay repeats wind down when stopped (≤ 0.85); the Wide
  delay's spread per sample; pressure sensitivity a curve (a full press always all the way); PW shown from X-Wave 70;
  Pitch glide in seconds; "OFF" in capitals; the lock-to-Swell message shorter.
- 2026-10-21 (the 0.2 polish): **Level** is an audio taper (squared: 50 is −12 dB); saved sounds and scenes convert
  to the same loudness (10·√v; PROJ_FORMAT 31), as do the presets and the starting sound (75 / 61). Weight's level move
  +27 (was +40), Wash's dip −11 and its breath −11 (were −15, −14): on the starting sound within 0.2 dB of before.
  Band-pass and high-pass get back about half the input the resonance takes (+4 dB at 100): 0..4 dB under low-pass
  at full resonance (was 4..8). A continuous knob's speed-up: 1 step a detent up to 6 a second, 6 steps from 26 a
  second (one brisk turn of 20 detents goes 0..100; was 1 step at 20 a second); Gesture time the same. The link offset
  reads "+8 st +20" (Evan; was "+8.20"). The emulator page has a favicon.
- 2026-10-21 (Evan, after trying #34): the knobs' speed-up is as before #34 (up to 4x, from ~40 detents a second).
  Gestures move a level in the knob's units before its taper (v²/100), so Weight (+40) and Wash (−15, its breath −14)
  are as approved at any level (within 0.1 dB of before #34). The encoders learn a detent only from a knob at rest
  ~0.5 s (was 25 ms), and a state outside the learned ones must be rested on twice in a row to join them (three times
  to replace them): slow turns missed clicks. The site has a link preview (og.png, 1200×630).
- 2026-10-21 (Evan, after trying #33-#35 on the FM-1): released as **0.2**, not a beta: a normal GitHub release
  (v0.2, niagara-drift-0.2.fwsc, identity FM-1_8000200); the README is 0.2's manual, linking 0.1's.
- 2026-10-21 (Evan): the emulator page and the README follow how a player meets it: Start here (PLAY, the presets,
  a gesture, Pitch lock off to tune, save in bank A), then Scenes, Gestures, Play, Tone, Switches, Movement, Effects,
  Setup. The emulator's FM-1 carries the README picture's labels, always. The site's top right has a "0.2 · What's
  new" pill (the changelog at the release's tag); the note under the FM-1 is "Version 0.2." and the risk.
- 2026-10-21 (Evan, after a designer's review): the emulator's FM-1 is black with light keys; a lit key is pale pink with a
  violet glow (dark text), a lit button pale pink. Its labels have three roles: the printed name 11 u grey, what it does 14 u in colour
  (no pills; Drone I / II as brackets over KNOB1-2 / 3-4), on the keys 12.5 u ink, at most two lines (violet: the LFO
  pages' name). Buttons name the page they open (FX Delay, LFO Depths, EDIT Osc, SAVE Store, PLAY On/off). Captions in a
  strip between the key rows; the gesture keys show their bank at the top. The README picture is drawn the same way.
- 2026-10-24 (0.3, step 1; Evan): two new LFO shapes on each wave, after Random: **AND** and **OR** (the Lyra-8's): a
  square at the LFO's rate with one 3x (Wave I) or 5x (Wave II) faster, multiplied (2 levels) or added, the slow one
  twice the fast (4 levels); centred, as every shape. A **drive after the delay**, before the reverb: the Delay page's
  KNOB 1 (Drive, Time, Repeats, Mix); the first fifth blends it in, then up to 26 dB into a soft clip with a little bias;
  its loudness matched to what goes in over ~0.3 s (P1, P9, P11 within 1.1 dB, 0..100). The delay and reverb types
  move to a **Types** page (FX, third tap: KNOB 1 delay, KNOB 2 reverb); Reverb is Length, Damp, -, Mix. PROJ_FORMAT 32
  (99 values a sound; 23-31 load with the drive off).
- 2026-10-24 (0.3, step 1, Evan after the "hear it first" recordings): two more delay types, **Grain** (Tape whose time
  its own sound moves, ~280 Hz and under, 60 samples a unit) and **Self** (Tape whose time its own loudness stretches,
  followed at ~10 Hz against its slow mean, 25 % of the time a unit): six in all. The pitch knobs go down to **2 Hz**
  (DR_PITCH_LO -2400 cents; was 27 Hz); under 27 Hz the screen shows Hz.
- 2026-10-24 (Evan, after a before/after recording): a new **reverb type** moves its lines and pre-delay to their new
  lengths at once, each read at both lengths for 50 ms and crossfaded (they glided, and the tail bent up to 7.6
  semitones for 1-2 s; now within ~0.6 of a semitone, a short dip in its place).
- 2026-10-24 (Evan, after trying 2 Hz on earbuds: the clicks too quiet at normal volume): under **A1 (55 Hz)** a drone's
  oscillators are made up by sqrt(55 / f) after the filter (+3 dB at 27 Hz, +14 at 2 Hz), the sub, noise, Character's
  noise and Feedback put in that much lower so they come out as before: a bare saw keeps A1's loudness down to ~14 Hz,
  and under that its clicks reach the output's clip (2 Hz: −9 dB against D3, was −18.5). 55 Hz and up unchanged (no
  preset goes under D2).
- 2026-10-24 (Evan): the **Sub key's round** gets **-3 oct and -4 oct** at its end (-1, -2 oct, 1/3, 1/5, -3, -4; saved
  values unchanged): only these two go under 20 Hz and click (a square: steady ticks, twice a cycle), with the same
  make-up; the others still hum over 20 Hz, unmade-up (a hum there is felt, not heard: lifting it would only take
  headroom). Each oscillator has its own make-up under A1 (the largest after the filter, the others in at their share
  before it, so the filter's drive is hit no harder). Lower partner intervals were tried and left out: the sub clicks
  on any wave and stays in time.
- 2026-10-25 (Evan, after testing 0.3 step 1 on the FM-1): a new **delay type** moves where it reads (the right side's
  spread, the wow, Grain's and Self's moves) at once, each side read at both places for 50 ms and crossfaded; its tone,
  output, ping-pong and gain still glide over 0.25 s (Tape to Wide had bent the right side's echoes 4-5 semitones over
  0.25 s). The **Delay and Reverb type knobs go round** both ways, as the LFO waves do. **Gesture time** (PRESETS)
  turns as a speed, right faster (shown x0.1-x10; saved values unchanged). **Scene time** starts at 63 (~15 s; was 46,
  ~4 s; a room setting: only a new FM-1 or a reset gets it). **ARP** works as the other page buttons: a tap opens the
  Swell page (switching nothing), a tap on the page is the Swell on / off, a hold peeks; the two-quick-taps rule is
  gone. The Swell page draws one bar, without "the swell, over two bars". A **black key** pressed while a scene is on
  its way is the hand's, as a turned knob's value is: the scene leaves it alone.
- 2026-10-25 (Evan): the **delay types in a new order**, plain to most alive: Clean, Wide, Ping-pong, Tape, Grain, Self
  (were Tape, Wide, Ping-pong, Clean, ...). Tape stays the default. PROJ_FORMAT 33: saved sounds and scenes from 23-32
  have Clean and Tape swapped once, so every sound keeps its delay.
- 2026-10-25 (Evan, after recordings; the ideas from players): **Into reverb** (Types, KNOB 3; P_DLY_ROUTE, the 100th
  value, PROJ_FORMAT 33): Both (as before), Echoes (the delay's echoes alone into the reverb, the dry kept whole and the
  wash added: +0.6 dB at a reverb mix of 45, +1.7 at 90), Drones (the drones alone into it, the echoes dry); a change
  crossfades over 50 ms. **Swell Shape** -100..100: over 0 as before (saved values unchanged), under 0 a ramp, the rise
  taking up to 97 % of each breath, the fall at least 20 ms. **Every knob of named choices goes round** (the types, Into
  reverb, Wander's scale; not a list ordered by size, such as Partner's interval).
- 2026-10-25 (Evan, on the FM-1: "Self is much stronger than the others"; 3 Hz picked by ear 2026-10-26): **Self**
  follows its loudness through two ~3 Hz stages (one let the level's ripple, at twice the pitch, shake its time at audio rate: FM, its echoes 2-9 dB over
  Tape's; at 10 Hz, two stages still warbled +-380 c with high repeats; at 3 Hz +-77 c, +0.6..+2.9 dB of Tape), and **Grain's and Self's moves of the time ease in and out over a second** on a type
  change (their followers run whatever the type). The Types page drops the reverb types' descriptions.
- 2026-10-25 (Evan, from a player's ask; picked ~1.5 s over 590 ms free or 2 s+ later): the **delay line at half rate**:
  the loop at the full rate, its writes down through the reverb's half-band (flat to 9.5 kHz), read back with an
  8-tap windowed sinc (Kaiser, 128 phases); the line 40960 half-rate samples a side (1.86 s, +32 KB of the pool).
  **Time** runs on the same curve past 100 to 163 (1455 ms), so saved times are unchanged. Presets within 1 dB; the
  echoes lose what's over ~9 kHz. Cost +143 host instructions a sample (worst case 2,555 with Self's fix, was 2,384).
- 2026-10-26 (0.3 step 2): **Cross-FM** is Cross-mod's third choice (black key 11 goes round off, cutoff (lit), pitch
  (winking); P_XMOD 0..2, saved values unchanged): each drone's sound speeds the other's oscillators (main, partner,
  sub) up and down, linear FM, drone I hearing drone II one block late. The modulator's lows under ~10 Hz out, soft-
  limited (x0.05..x1.95), its mean out after the limit: both drones within 0.2 cents of their pitch at every depth
  (a test). X-mod amt the depth (10x the sound at the top). Loudness within 1.3 dB; worst case 2,570 host
  instructions a sample (filter mode stays the dearest, 2,593).
- 2026-10-26 (Evan, after recordings: today's Feedback faint, "output as FM" liked, the two too unlike for one dial):
  **Feedback** at a steady strength (the loop's level followed at ~3 Hz and made up to 0.25, x8 at most), its gain
  0.9 a unit up to 70 then rising to 4.0 at 100, its cap 0.45 rising to 1.6 over the top, the loudness held by a
  quarter power of what it adds and a trim of 1 dB at 70 to 5 dB at 100: P1 within +3.8 dB; the meter its share.
  **Snarl** is Cross-mod's fourth choice (P_XMOD 3, winking): the finished sound, fb_d samples ago, bends both drones'
  speed as cross-FM does (lows out, soft-limited, mean out after), its level made up to P1's (0.22, x8 at most); X-mod
  amt the depth (9.8 at the top). Worst case 2,660 host instructions a sample (cross-FM), Snarl 2,654.
- 2026-10-26 (0.3 step 3; Evan's answers after a clock test from Logic: 0.2-0.4 ms jitter with the drone stopped, ~1.5
  ms at 78 % load): **MIDI clock in** (USB, TRS) moves the Swell. Each packet stamped as it comes in (us, kept by the
  10 kHz tick); the tempo a straight line through the last 48 pulses, shown in whole BPM moving past 0.6. With a clock,
  the Swell's KNOB 1 is **Division** (P_PULSE_DIV, PROJ_FORMAT 34: 32 bars .. 1/4 a breath, 8 bars to start); its
  speed the clock's tempo, its place steered 2 % a block toward the beat counted from the pulses (no drift: within 1.3 %
  of a quarter-note breath over 10 minutes of +-4 ms jitter); scenes keep it in time; Start back to the top; stopped,
  it carries on at the last tempo. The locked LFO follows the Swell's bars. A test build (OM_CLOCK_TEST) shows the
  tempo and jitter; tools/fm1_clock.py reads them over USB (SysEx 0x7C).
- 2026-10-26 (Evan, after trying it on the FM-1 with Logic): on a MIDI clock **scenes leave the Swell's on / off and its
  division alone**, and more follows the clock: the **LFO** (SELECT turns P_LFO_DIV, 32 bars .. 1/16 a cycle, steered
  0.5 % a block toward the beat), the **delay** (Time turns P_DLY_NOTE, 1/16 .. 1 bar, halved to fit 1.46 s; its tempo
  steadied: a change over 0.4 % glides it in, till within 0.05 %), **Wander** (a note due waits for the next beat, or
  bar when they're over ~6 beats apart), the **Scene time** (P_SCENE_BARS, a room setting, 1 .. 16 bars; a change ends
  on a bar line: the rest of this bar and the bars after, a bar more under half a bar). PROJ_FORMAT 35 (104 values).
- 2026-10-27 (Evan): **CI and the review.** GitHub Actions runs the host tests, the scenarios and the emulator on every
  PR and on main (`tests.yml`), and counts the engine's cost case by case under valgrind against main (a warning past
  +2 %). The Claude review runs when a PR opens or is marked ready (again on "@claude review again"), reading
  `.claude/CLAUDE.md` (the FM-1's budget, what the build enforces) and `.claude/rules/dsp.md` (audio code). Every
  firmware PR body carries `tools/budget.py`'s line: RAM, pool headroom, image size and the engine's worst case,
  against main.
- 2026-10-27 (Evan): **the mapping (0.3, step 4).** HOME's pages are **Drones 1 / 2** (were Play 1 / 2). The SEL map draws
  the top four white keys as the **banks** they pick (A, B, C, P), the one playing lit. **One-time tips**, once each, when
  the screen is free: PRESS HARDER: BLEND (a scene tap), HOLD SEL: KEY NAMES (a black key), HOLD: IN · TAP: LATCH (a
  gesture), TAP FX: REVERB, TYPES (Delay), KNOB 3: INTO REVERB (Types), KEY 11: PITCH, SNARL (cross-mod on), SWELL KNOB
  1: DIVISION (a clock), SEL + SAVE: UNDO (a scene replacing a sound of your own); seen flags in the project's spare
  bytes (no format change), saved with the next save. **A crossfade stays when you let go**, where it was 150 ms before
  (the finger lifting); SEL no longer holds it. **SEL + SAVE undoes** the last scene tap or blend, over the Scene time;
  again, forward. The Sub key with OSC MIX at 0 says so after its step ("OSC MIX 0 · EDIT x2"). Pitch lock stays as it
  is (scenes keep your pitch while it's on); the pitch knobs on semitones go with clock out.
- 2026-10-27 (Evan): **same samples.** Every PR is checked against main for sound and screen: `tools/same_samples.py`
  plays the fixed renders in `tests/golden` (each preset, the worst case with cross-FM and with Snarl, each gesture
  held, latched and kept, scenes with a blend and undo, the MIDI clock), every scenario and the engine's own scenes
  through both, and compares every WAV sample by sample (same; close: within -90 dBFS; different) and every
  screenshot pixel by pixel. CI fails a PR on a difference unless it carries the label `changes-sound`. Efficiency
  work comes next, with this under it: measure first, then fix by payoff.
- 2026-10-27: **RAM: 16.5 KB back** (80.5 -> 64.0 KB of 96; the efficiency report's fixes 1-3). Old saves convert read in
  place from the load buffer (their copies were 12.1 KB); a Preset is built when it's asked for, one at a time
  (`scene_has()` for the keys' lights and the pressure check); the Presets saved over before 2026-10-19 are moved
  straight from the load buffer, and their object is rewritten after the banks and the project that now hold them.
- 2026-10-28 (Evan): **eight gestures; scenes on keys 1-8.** Keys 9-12 (G4-C5) are gestures on every bank, by pressure
  (toward how hard the key is pressed, over the gesture's time, 6.5 s at Gesture time 50): **Tick** (the sub's own rate
  sinks under 20 Hz into beats, 2^-7 of the drone, and speeds up to 2^-3), **Chord** (the partners to a just chord from
  Wander's scale, spread open, one of 5 voicings at random each press), **Snarl** (drone II detuned, Snarl, the drive,
  Feedback at the top), **Stutter** (the Swell on: its rate, depth, then a hard shape); each the partner of the top key
  four to its right. A tap latches any gesture at 100; SEL tapped while one is held latches it where it got to. A bank
  plays 8 scenes; the Presets P1-P8; P9-P12 start in C1-C4 (an updated FM-1: copied into the first empty keys 1-8 of C,
  B, A). Scenes on keys 9-12 move once to the first empty key 1-8 of their bank, then another's; one with no room stays
  stored. A partner's interval now crossfades when it changes (down, swap, up). PROJ_FORMAT 36 (108 values: the new
  gestures' latches `P_GL_4`-`7`). The 9 unused parameters stay (retiring them renumbers everything after them).
- 2026-10-28: ENV opens on **Life** (Character, Feedback, Age, Drift), then **Tone** (noise, colour; was "Tone 1"):
  the most played of the two first. While Shift moves a drone's pitch, its pitch card lights and shows the pitch as
  heard, "SHIFT" under it. From review 5 (playability).
- 2026-10-28 (Evan, from review 5): **FX is two pages, the Types page folded in.** Delay: Drive, Time, Repeats, Mix;
  Reverb: Length, Damp, Type (the knob that was empty), Mix. KNOB 4 on each has a second job with SEL held, the choice
  made before playing: the delay's type, and what goes into the reverb. Its card shows both at all times, in two
  halves: the mix above, "+ SEL Type" / "+ SEL Into" below; the half turning lights, and while SEL turns it only the
  mix half dims. The delay picture no longer shows "drive" (it has KNOB 1). Parameters unchanged (no PROJ_FORMAT).
- 2026-10-28 (Evan, on the FM-1): the **motion loop records gestures and scenes** too: each gesture's level as played
  (and its latch), a scene tapped, a scene blended by pressure. Played back, a gesture is the loop's or the hand's,
  whichever is more; a loop with scenes starts each pass from the whole sound it began on. On Delay and Reverb, SEL's
  key map waits 1.5 s (0.4 elsewhere), and once KNOB 4's SEL job turns, not until SEL is let go.
- 2026-10-28 (Evan): **each drone's sub wave** is a choice, SEL + its Osc mix knob (Sub · Drive), the card in two
  halves: Square (as before, the default), Sine, Triangle, Saw, each as loud (RMS) as the square, a change gliding
  through as the octave's does. PROJ_FORMAT 37 (110 values: `P_SUBW_0`, `P_SUBW_1`). **Gesture time** respread: 50 as
  before; slower evenly in seconds to x12 (Weight 34 s), faster only to x4 (0.7 s); shown as Weight's time ("2.8 s").
  A per-note envelope for Wander was drawn and set aside; a Lyra-like "plate" gesture (pressure opens a drone) is a
  0.4 idea.
- 2026-10-30 (Evan): **the web installer backs up first**, as the terminal one does, into the downloads, and offers the
  backup back after the install; a card saves or restores one at any time. Both write the same file, now with a CRC-32
  for each object (a damaged file is refused before anything is written; older files without them still restore),
  each object read twice (one changed meanwhile is refused), and **without the panel's calibration** (it belongs to
  the unit; an older backup's is skipped on restore). After fm1-base's and Melodee's. Still the 0.2 backup commands,
  so a 0.2 FM-1 is backed up before it's updated; a restore that changes the set whole or not at all, with a yes on
  the FM-1's screen (fm1-base's), is for a later PR.
- 2026-10-30 (Evan, step 6, after listening): the **drone drive is antialiased** (first-order antiderivative
  antialiasing of its soft clip, blended in from Drive 40 to 60; below 40 as before): at 100 on a saw at A5 the energy
  between the harmonics -25 -> -38 dB (A-weighted), +65 instr/sample in the worst case. The delay's drive stays as it
  is (not heard). **The square is 3 dB down** (`OSC_SQ_K`): it was 2.6-4.1 dB over the saw on the speaker, now
  +0.2 / +1.4 dB (D3 / A3); X-Wave's saw-square blends follow. The delay's 16-bit floor (~-90 dBFS) stays: not heard.
- 2026-10-30 (Evan): **the Swell's Shape turned round**: even in the middle, the ramp to the right (toward a saw),
  firmer to the left (the hard gate at the end); saved sounds and scenes are converted so they sound the same
  (PROJ_FORMAT 38, the value negated; the default −25, Stutter toward −85). **A scene blend kept as a gesture is**:
  pressing shows "A1 40%", a SEL tap keeps it right there ("A1 40% KEPT", the key then let go any time), and letting
  go without it glides back to where it was, at the speed it came ("A1 BACK"), as in 0.2. SEL + SAVE undoes a kept,
  taken or tapped scene (how is a one-time tip); one let go back leaves nothing to undo.
- 2026-10-30 (Evan, by ear on headphones): **the pitch knobs land on a Tuning**: a turn glides without steps (60 cents a
  detent, as before) and, stopped, slides to the nearest step of the grid over 250 ms (80 ms was a snap, 600 a bend).
  Stopped is no detent for half again the time between the last two (150-600 ms; 600 after a first one), so a slow
  turn stays one glide. SEL turns a cent a detent and doesn't land; where it leaves the pitch off the grid is kept
  (`proj.tun_off`, the player's) and every later landing keeps it. **Tuning** on Setup 2 KNOB 4, going round: 12-tone,
  Quarter, 19-, 31-, 53-tone, Just (5-limit, from A), Young (La Monte Young's Well-Tuned Piano, 7-limit; on A, as
  the others), Harmonics (odd harmonics 1-15, octave-reduced), Shruti (22, from A as Sa); all built on A, so Tune moves them;
  a room setting. Pitch link's offset lands on the grid's intervals. Free's 60-cent steps dropped. PROJ_FORMAT 39
  (111 values: `P_TUNING`); old sounds keep their pitches until turned. Young's tuning and the harmonics (Evan: La Monte
  Young is the firmware's main inspiration).
- 2026-10-30 (Evan, on the FM-1, after #61): **a pitch knob's detent is the Tuning's next note**, up or down (2 when
  turned quickly), gliding over the time since the last detent; the card shows the note it goes to. #61's glide of 60
  cents a detent, landing once stopped, could land back on the same note on the uneven grids and showed the cents in
  between. A pitch off the grid steps to the grid's next note beyond it. Young's tuning is named **LMY**; it, Just and the
  shrutis are placed as Ableton's tuning files place them, A 440 one of their notes (Just: Ptolemy's 5-limit with C on
  1/1 at C+16, A its 5/3; the shrutis' Sa on C at C-6, their MaL+ 64/45). The equal tunings stay: A 440 is a note of each,
  so which note is 1/1 makes no difference. Two more Tunings, at the end: **Harrison** (Lou Harrison's National Steel guitar, 11-limit, 12 notes)
  and **Partch** (Harry Partch's 43, 11-limit; his own G 392 Hz is Tune +4), both with A 440 one of their notes.
- 2026-10-30 (Evan): **Just and Shruti move with drone I** (a movable do: just is pure from its tonic): drone I's knob
  picks the tonic in semitones; drone II's knob, Pitch link, Wander and Chord are pure over it. Their tables are from
  their own 1/1 again (Ptolemy's 5-limit; the shrutis from Sa, MaL+ 64/45). The other Tunings stay fixed on A.
  **Wander's notes and Chord's follow the Tuning**: 12-tone and Quarter as before (Chord pure); the 12-note Tunings
  (Just, LMY, Harrison) the same keys; the rest the Tuning's note nearest the pure interval (31-tone's minor third
  310, 53-tone's 317); on Harmonics Wander moves among all the harmonics. The Tuning tables moved into the engine.
- 2026-10-30 (Evan): **the Tunings in order**: 12-tone first (the most common), the equal ones by size (Quarter, 19-,
  31-, 53-tone), then the rest simplest to richest: Just, Harmonics, LMY, Harrison, Shruti, Partch. PROJ_FORMAT 40
  (39's read, its Tuning remapped: a saved sound keeps its Tuning).
- 2026-10-30 (Evan): **the safe restore, on fm1-base's flash core** (`restore_core.c`, MPL-2.0, as it is there: proven
  on FM-1s, and storage.c unchanged). Each object of a backup is checked against its CRC-32 and staged in its spare
  copy without its header (nothing changes); then the FM-1 asks, RESTORE FROM USB? (SEL yes, HOME no, a minute: no;
  one banner line, the question and its keys in turn); yes, the journal record (the update area's second sector),
  the headers, the record erased: the set changes whole or not at all, a power cut finished at the next power-on;
  then it restarts. Every object of the list is restored (one the backup hasn't, emptied). Saves wait while a restore
  is staged. USB 0x74 (stage) and 0x75 (ask); the installers fall back to 0.2's way on firmware without them.
- 2026-11-01 (Evan): **0.3's knob moves and names**, before the new look: Life is Feedback, Drift, Character, Age (the
  one turned most first); Mods' knob 3 is Delay mod and 4 Cross-mod (the LFO's three together); Setup 2 is Tuning,
  Tune, Stereo, Pressure. Renamed: Osc mix → Osc/Sub, Switch time → Morph, LFO depths → LFO sends (its knobs named for
  what they move: Pitch or X-Wave, Cutoff or Reso), Rate mod → Speed mod, Mod by → Source, Dly LFO → Delay mod, the
  OCT waves LFO I and LFO II on screen; the Swell's Shape reads gate, pulse 50, even, ramp 40. On the knobs the short
  forms Feedbk, Char., Press., X-mod, Speed, Delay, Osc/Sb, Repeat, Morph, Scene. The old pictures follow the knobs,
  the left half KNOB 1-2. Parameters keep their numbers: no PROJ_FORMAT change, saved sounds load as they were; the
  sound is the same sample for sample (30 renders, main's scripts on main against the remapped ones here).
- 2026-11-01 (Evan): **0.3's new look, its foundation and Drones 1** (`firmware/src/app/look.c`): the header, the
  banner and the tip, the SEL tag, the values row and the dot meter, at the sizes Evan judged on the FM-1 (the page
  name 22 bold, knob names 20 falling back to 18 and 17, values 26 / 21 with the unit smaller, the banner 19, small
  words 16-18; every line on one baseline: gen_font.py writes each font's). The header, full: the sound's name gives
  way first, then PLAY's state to its short form, the "1/2", SWELL, the key; never the page's name. Drones 1's
  picture: each drone's wave as six strands, 2 px, scaled to its own loudness; the interval from drone I to the
  nearest semitone with an up or down arrow (no cents, no "above I"). The other pages as they were until their PR;
  the key map and the big readout too. The same sound.
- 2026-11-01 (Evan): **Drones 2, Osc and Sub · Drive in the new look**: Drones 2 each drone's filter curve as six
  strands (its last cutoffs) as high as its level, the level in dB under it, Resonance's last dot red; Osc each wave as
  six offset strands, EDIT's stripe gauges (X-Wave's with its four waves marked), X-Wave's values short ("saw",
  "tri", "saw/sqr"), PW grey with "at square" when it does nothing; Sub · Drive the osc and sub lanes, each its share
  of the equal-power crossfade, through the drive's soft clip, Osc/Sub's crossfader meter, the sub's wave on a SEL tag
  above the knob ("mix 40" while SEL is held, when the column shows "Sub wave" and its four segments). The same sound.
- 2026-11-02 (Evan, on the FM-1): **Osc and Sub · Drive redrawn, PW renamed Width**: each wave one 2 px line in its
  drone's colour (strands are for what moves; still, they read as a lo-fi band), Osc's about a third of the picture
  tall, Sub · Drive's half its lane. PW is **Width**; while the wave has no square its value and meter go grey and
  "needs sqr" sits on the rule above it, clear of the meters. The same sound.
- 2026-11-02: **Life and Tone in the new look**: Life a drawing above each knob, all moving, in the neutral ramp:
  Feedback's rings (one a 20, shaped by drone I's sound, breathing with its share; from 70 spread wide, the outer one a
  thin red ring rippling), Drift's flame (nine strands, as far as Drift lets them), Character's first nine harmonics
  (drone I filled, drone II outlined, a clean saw's as ticks), Age's worn saw (from Age as heard: rounding, wow,
  flutter, hiss). Tone each drone's noise as snow, low to high, as high as its level, tilted by Colour and cut by the
  filter, its specks pink as often as Colour says, each changing about once in seven pictures. ENV's meters square
  cells (Feedback's last two red, Colour white to pink); "Pink 70" with the word small. The same sound.
- 2026-11-02: AGE and CHARACTER stronger (Evan, by ear on renders: both "Stronger"). Age at full: the cutoff -250 of
  its 1000 (about 2.5 octaves darker; was -70, under a third of an octave), hiss +20 (was 15), a wow of +-25 cents
  (was 14), and 5 dB of level made up as it wears in, so it darkens without going quieter (within 0.2 dB on a steady
  sound). Character at full: the highs rolled off from 500 Hz (was 1.2 kHz), the bend 0.35 (was 0.25), the jitter
  doubled. The Presets and Weight keep their approved sound with lower values: Character 40 → 27, 30 → 21, Tape's
  Age 80 → 35 and Character 98 → 67, Weight's Character +25 → +17. Life's pictures read the same constants
  (drone.h), so Character's harmonics now fall visibly from the clean saw's ticks.
- 2026-11-02: A gesture never brings back a drone at Level 0 (Evan, on the FM-1: Weight brought it back at about
  -28 dB, and no other gesture does). Weight's level lift fades in over the knob's bottom tenth: none at 0, as approved
  from Level 10. A key is named by its note, in a box like SEL's, never its number ("[F#5]", not "key 11"). Partner,
  Pitch moves, LFO sends and Mods in the new look (PR E); strands 1 px with a gap where they'd blend (Wander, Partner),
  Osc's stacked straight down as Drones 2's; a drone's strands follow the level heard, closing up and dimming toward
  silence (Drones 1, 2, Sub · Drive). The same sound otherwise.
- 2026-11-02: Every button and key on screen in a box, and a message says what to do ("II OFF  turn on SEL + PLAY",
  SEL and PLAY boxed). Nothing jumps: a line that comes and goes keeps its place, gray when idle (LFO sends'
  Movement and Swell lock). No sliders on LFO sends or Mods, nor cross-mod's amount bar: the knobs' values say it.
  A setting shown at the page's top with its key (Partner, the sub's octave, the filter) gets no banner there.
- 2026-11-03: Swell, Delay and Reverb in the new look. The Swell: a bar of its two breaths in dB, six strands meeting
  at the dot (the fan 0.09 / (1 + 2.2 Hz) of a bar), nine coral pills a meter; Shape as its number with its kind
  under it (gate 100, pulse, even 0, ramp), since the picture shows the shape. Delay and Reverb on log time axes
  (Delay 42 + 60 ln(1 + t / 0.1 s), 2 s; Reverb 84 + 37.7 ln(1 + t / 1 s), 40 s): echoes as half-rings
  48 sqrt(wet fb^k) tall, L blue up and R aqua down; the tail as rings as tall as it is then, drained by Damp;
  runaway red and freeze blue in the header. KNOB 4's second job as the SEL tag above Mix (both pages say "Mix").
  A value too wide at 16 px steps down to 13 ("Cathedral").
- 2026-11-04: LFO sends is the wiring as sentences (Evan's board): each drone's two sends "[F#3] LFO II → [G#3]
  x-wave", "[A#3] LFO I+II → [C#4] reso", the keys where they sit, a send at 0 gray; under them the LFOs small and live,
  the rate, the Swell lock; "movement 0%" when Movement grays every route. The same keys on both LFO pages; no banner
  for a key whose change the page shows (the routes on LFO sends, the delay's LFO and cross-mod on Mods). The key
  order stays (D#4 the reset between the drones).
- 2026-11-07: the Swell's strands 2 px, five of them (were six of 1 px: thinner and rougher than every other page's);
  the fan as before, meeting at the dot. The picture two bars across at every speed (four breaths, 54 px each; was
  one bar): the rhythm reads as a rhythm; the dot crosses both, the screen counting which bar it's in; the fan half
  as wide a breath, so its widest spread stays.
- 2026-11-07: Delay's and Reverb's rings 2 px, as every page (were 1 px); Drive thickens the Delay's from there (3 px
  from Drive 34, 4 at 100).
- 2026-11-07: LFO sends: the LFOs above the routes, I over II (on one row the longest names ran into the rate), their
  waves in one column, 13 px tall and 54 long (were 9 and 24); the rate right of LFO I, the lock right of LFO II;
  locked with the Swell stopped, "on Swell" dimmed (was "waits Swell", too wide beside the waves); "mvmt 0%" in the
  rate's place when Movement is 0 (the rate isn't heard then).
- 2026-11-07: Setup 1 and 2 in the new look (PR G; the overlays moved to their own PR, H). Setup 1: a row per time,
  its title with the knob's word bold, a symbol across the row ending where its knob is (the knob's whole range the
  row; Evan: turned all the way it reaches the end): Fade one thick line up from silence, Morph and Scene a crossfade
  (a out, b in); the knob being turned marks its time with a dot there; on a clock, Scene's knob is its bars. KNOB 4
  **Sync**: on (default) follows a MIDI clock, off ignores it and forgets its tempo (the Swell, LFO, delay, Wander and
  Scene time back on their knobs), a Start too; under it "no clock", "120 BPM", "keeps 120" or "free time"; a room
  setting (`P_CLK_SYNC`, the 112th value; `P_SYNC` is hard sync). Setup 2: Tuning and Tune one ring (an octave
  clockwise, a tick a note, A named, Tune turning it from a fixed notch; the 1/1 named: LMY C, Harrison and Partch G,
  Harmonics A, Just and Shruti drone I at the top: its tick long and white, no label outside; Evan), centered in the
  picture; no drones or interval on it (Evan: the
  page sets the tuning; Drones 1 shows the interval); Stereo the two waves as far
  apart as it puts them; Pressure the curve with the key pressed ("[C4] 62%"). **Tune in Hz**: A's pitch in tenths of
  a Hz from 440 (427.0 .. 453.0), 1 Hz a click, 0.1 with SEL; a saved Tune in cents becomes the nearest 0.1 Hz (at
  most 0.2 cents off: -32 cents is 431.9 Hz). PROJ_FORMAT 41 (39-40's 111 values widened). Meters: Tuning a marker on
  a track, Tune a dot row from the middle, Stereo a slider; Sync none, its line says it. A long Tuning's name steps
  down to 15 ("Harrison") or 12 ("Harmonics", a new 12 px font) to fit 52 px; A and the 1/1 a little off the ring.
- 2026-11-07: the time knobs (Setup 1) on a power curve (Evan: an exponential one gave 40 % of the dial to under a
  second; a drone is about slow changes): Fade 0.05 + 59.95 x^3 s, Morph 0.02 + 29.98 x^2.5 s, Scene time 0.1 + 299.9
  x^4 s (`dr_time_s`), 1 s near a quarter on each (25, 25, 23 %), the ranges kept. Saved ones converted to the same
  time (PROJ_FORMAT 41); the defaults 25, 21, 48 (0.99 s, 0.63 s, 16 s; were 42, 47, 63). The starting passage
  measured on main and G: the fade in to -3 dB 1.70 s on both, the loudness 0.09 dB apart on average.
- 2026-11-07: the meters one family (Evan: "dots, cells and pills look the same"): every plain amount a row of 8 dots
  of 5 px in its page's own colors (ENV's cells, ARP's pills, EDIT's stripe gauges and SEQ's rulers before it); kept:
  a caution's red (Reso's last dot, Feedback's last two), the centered rows from the middle (Shift, Tune, the Swell's
  Shape), the crossfaders (Osc/Sub, Color, Stereo), X-Wave's ticks, the segments for a few choices (Reverb's Type,
  the Sub wave); Mods' Source and Wander's Scale keep their dots, one lit (Evan, after trying segments).
- 2026-11-07: changing the Tuning (Setup 2) clears SEL's fine tuning (`proj.tun_off`, each pitch knob's offset off the
  grid): an offset set by ear against one Tuning's notes means nothing on another's (Evan); the drones keep sounding
  where they are until their knob turns. The "fine" tag over a turning pitch knob (Drones 1) shows the offset ("fine
  +3", "fine 0"): on the Tunings besides 12-tone the note's own cents hid it (LMY's Bb3 -37 became -34; Evan, of
  three: the tag, the note with the offset under it, or nothing).
- 2026-11-07: 0.3's overlays in the new look (PR H, the board 321:2), and the old screen's code out (`draw_bar`,
  `draw_pic` and its `pic_*`, `draw_values`, the old key map, its palette and the font M: about 1,200 lines). The
  header: a gesture as a gold badge with how far in it is ("WASH 40%"; Evan on the FM-1: the number says more than
  four cells did), "latched" once a tap or SEL keeps it; at the
  right the sound's key (a Preset's name with room), "changed" once a hand has moved it (a bank picked isn't a
  change); on its way to a scene, where to in the sound's place, gold ("→ P3 EERIE", "→ A5" back), a gold line under
  the header filling as it goes, shown at least 1.5 s as a subtitle is (Evan, on the FM-1 at a 0.1 s Scene time: it
  flashed by), PLAY's fade too; a page button held "PEEK" and "let go: DRONES". When it's full, what gives way, in
  order: the sound's name, PLAY's state to its short form, the "1/2", "changed", SWELL, the key, a latched gesture's
  word, PLAY's state; the page's name never; what gave way comes back where it fits again. No gesture or scene banners ("SCENE P3 EERIE", "A5 BACK"): the header
  shows them (Evan: one place).
  The key map: KEYS [SEL] held, the black keys lit in their groups' colors (I, global, II, links; on the LFO pages I,
  both, II, mods), the one touched outlined in white, "LINKS · [D#5]" and "HARD SYNC ON" under it. The tips for the
  knobs 0.3 moved (Feedback KNOB 1, Cross-mod 4, Tune 2), once, for a player from 0.2 (a new FM-1 starts with them
  seen: `SEEN1_MOVED`). Also: a value of words alone is one name in one size ("Chorus hall" on one line); the Swell's
  breaths centered up and down (Evan).
- 2026-11-07: the panel's lights, after an outside review of them beside the screen (Evan picked all eight): stopped,
  PLAY breathes (40-255 over 3.6 s) and nothing else moves (OCT- / OCT+ and ARP a still dim 64, as their settings
  stay shown); the black keys: dark always off, a plain switch lit on (Partner, Pitch lock, the links, hard sync), a
  key of two or three live choices dim on its first (-1 oct, LP, LFO I, Pitch, Cutoff), lit on the second, winking on
  a third; dim is 64 (2 frames of 32, beside the gesture glow's 40). One clock for the slow blinks (1.2 s: the wink on
  1.0 s, the scene you're on 0.72 s). A scene gliding in brightens its key with the header's line; gliding back the
  left key dims. REC blinks once a second recording, fast in the last 20 s before FULL. SEL glows (128) while it can
  keep a blend or a gesture, with a one-time tip "TAP [SEL]: KEEP IT". SEL held, the map on screen: D5-G5 light as
  the banks (the one playing lit, the rest dim). A key or button a message names in a box blinks quickly (150 / 150
  ms) while it shows. The key map draws the same four looks; the emulator shows dim keys too.
- 2026-11-08 (Evan, ledger 3): **a sound carries its Tuning.** The Tuning is no longer a room setting: a scene
  brings back the Tuning it was stored on, even with Pitch lock on (the lock keeps the drones' pitch, not their
  grid); a Preset that names no Tuning plays on 12-tone, as it was made. It flips half way through a scene's glide
  (as a switch does; it has 11 choices, so it was listed apart), and any new Tuning, by the knob or with a sound, lets
  go of SEL's fine tuning (`param_set`). The knob stays on Setup 2. No new save format: scenes always stored the
  Tuning, it was only skipped when they played.
- 2026-11-08 (Evan): a scene key pressed part way and let go: the header keeps naming that scene ("→ A3") and its gold
  line runs back down from where the press got to as the sound returns (it had filled a new line to "→ back", which
  looked as if the change went on). An undo's glide still fills its line.
- 2026-11-08 (Evan, ledger 3a): **intervals in each Tuning's own terms**, as composers and tuning files write them:
  on the equal Tunings by steps over the division ("11\19", as Ableton's tuning site and the xenharmonic writers do),
  on the others by ratio ("3/2", "7/4"; each Tuning's ratios in flash beside its cents, `dr_tun_name`). Drones 1's
  interval, a partner's and Shift's, between the two notes' nearest on the Tuning when the gap heard is within 10 cents of
  theirs (Evan: exactly on the notes was too rare, and a name the drones aren't playing would mislead); 12-tone keeps
  its familiar names, and a gap further off or a ratio past 7 characters falls back to them. Pitch values stay notes and cents. Swara names for Shruti and harmonic numbers
  were considered and left out (simpler; a Shruti naming would need an Indian musician's check). The screen fonts
  without the drawn arrow carry a real backslash (it was a blank slot).
- 2026-11-08: the LFO on **X-Wave and the resonance turns at their ends** (Evan: a sweep should be heard all the way
  round). Its swing was cut off there, so at depth 100 X-Wave sat on the square or the sine 27 s of every minute and the
  resonance held its full whistle 5 s; now the sweep stays centered on the knob while it fits and slides away from an
  end when it would run past it. Depth 100 is now the whole range (it was reached at 50 on Reso and ~70 on X-Wave; past
  that the knob did nothing more); saved sounds are converted to the range they reached (format 44). The cutoff's
  sweep stays centered on its knob, as on most synths, its edges unchanged: the fix there is the sounds' own cutoffs
  (the starting sound's: drone I's cutoff 70 to 57.5, 2.3 kHz to 1 kHz, drone II's 68 to 60, 1.2 kHz, the levels 75 to
  84 and 61 to 68 for the same loudness; its sweep's dull stretches halved, 12 s a minute to 6).
- 2026-11-08: **the pages played open first** (research on what drone players move by hand, a standalone playability
  review and a playable test, ledger 20): HOME opens **Drones** (I level, I cutoff, II level, II cutoff; Drones 2's
  picture, each drone's note small at its half's right) and **Pitch** is behind it (pitch and resonance; Drones 1's
  waves; a drone's half shows its filter curve while its Reso turns and 1.5 s after). FX always opens **Space** (delay
  repeats and mix, reverb length and mix, two halves DELAY and REVERB, each Mix named by its half), **Details** behind it (drive, time, damp, reverb type; SEL + KNOB 2 the delay's type, SEL + KNOB 4
  Into). Pitch lock keeps the drones' pitch through scenes and Presets only: the pitch knobs always tune. Partner's
  Detune with its partner off is gray, "needs [F#3]" / "[F#4]", the key blinking while it turns. A 30-minute set took
  ~24 page taps against ~42 (the review's estimate). The other pages stay where they are.
- 2026-11-08: **auto-return** (Evan's idea, ledger 21): a page left alone goes back to Drones, the page played, 8 s
  after it was opened or a knob last turned on it (keys and gestures don't count; not while a page button is held or
  SEL is). Hold SEL and tap a page's button to keep it ("kept" in the header) until another page. The return is a
  plain switch. The host's scenarios have it off unless they say `autoreturn`. **Taken out 2026-11-10** (Evan, on the
  FM-1: "kind of annoying"), SEL + a page's button with it: a page stays until the player leaves it.
- 2026-11-10: **Wander comes with a scene**, Pitch lock on or off (Evan, 2026-11-08 and 11-10): the lock keeps the
  drones' pitch, Pitch link's interval and Shift only. Before, with the lock on, Wander counted as pitch, so a scene
  saved with Wander left it running through every scene after it.
- 2026-11-10: **a drone alone sits in the middle** (Evan: Bare "is more on the left"): Stereo's spread scales with the
  other drone's fade, so with drone II out (II OUT, Bare) drone I glides to the center, and back out as II comes in.
- 2026-11-10: **the 16 Presets** (Evan, after eight audition rounds and six test builds on the FM-1): two banks of eight,
  each mixing moods, nothing too strange at P2: P1 Niagara, Embers, Vespers, Dreamhouse, Abyss, Seance, Sonar, Sibyl |
  P9 Howl, Cistern, Piston, Ashram, Telegraph, Tape, Falling, Bare (locked, drone II out, level 80). Each moves over a
  minute; names from each sound's own world. Leveled to P1's loud moments (12 within 0.1 dB; Abyss, Vespers -2.5;
  Ashram -5.7 on the speaker measure, its bass). Howl's random LFO at 100 (was 90), so its grind comes back every
  10-15 s however it's started. Shimmer (the flicker: two octave-up head pairs 14 cents apart) is reverb type 5, on
  Cistern; to be tuned later. Updating from 0.2: its dropped Presets (Eerie, Glass, Tanpura, Whistle, Cathedral,
  Metal) go into bank F, nothing else copied (Heaven is Sibyl, Clean is Bare).
- 2026-11-10: **Shimmer, the simple way** (Evan, from four rounds of renders: "L"; the first was "dissonant ... a
  little menacing"): the octave is shifted once, before the reverb, and nothing feeds back (Sound On Sound's recipe;
  the Big Sky's Input mode), into the Hall's own room, so a switch from Hall changes only the halo. The octave in two
  voices 14 cents apart (20 was out of tune, 8 too tame; in tune together, fed back, it rang away), 1.6 into the
  reverb with the drones cut to 0.4. It washes in over 8 s and out over 6 ("it should wash in and out"). Still a
  reverb type, played with Length and Mix. Cistern keeps its loudness (within 1 dB), 2-7 dB less bright at 1-4 kHz.
  A reverb type's crossfade is 200 ms (50 jumped up to 6 dB leaving the Cathedral).
- 2026-11-10: **the screen reader** (issue #87, João Durães; Charles Vestal's fm1-reader, its firmware side from fm1-base,
  MPL-2.0): the screen as text over USB SysEx, words in full from `firmware/words.tsv` (published with the site). A page
  says its name and knobs as it opens (about 20 words); its key hints, each with what the next press does ("A#3 for
  band-pass"), come when the reader asks for everything, a key is pressed, or SEL is held and a key touched (Evan: the
  keys' names alone didn't say what they do; then fewer words a page). Drones as "drone 1, 2"; scenes "scene A 5" (A5
  is a note); flats, cents, minutes and intervals in words by the firmware. 1.3 KB RAM, 7.1 KB flash. A Helper / Pro
  setting that turns the help on and off is its own piece, later.
- 2026-11-11: **the manual as pages of the site** (Evan, from a prototype played in the browser): Markdown in
  `docs/manual` (it reads on GitHub too), made into `/manual/` by `tools/make_manual.py`; the README keeps what it is,
  installing and links. Five ways in: Start here (from a Preset, or from Bare built up), Recipes, Reference (the
  README's pages as they were, then rewritten short page by page, as the gestures already are), Shortcuts (not
  "hidden moves": nothing is hidden), Help. Every page: Install, Source (GitHub's mark), a menu icon for the rest, a home
  icon; a banner whose two bands run corner to corner and turn the words pale where they cross. Recipes are for what
  one knob doesn't do (a key and a knob, or two or three pages), in five kinds, a page each with every recipe listed
  at its top: Sounds, Gestures, Scenes and saving, Time and transitions, Performing. Each: what you hear, the moves,
  Good to know, two screens and a sound, its own link and Share. The sounds are host renders from scripts in
  `docs/manual/renders`, each recipe from a different Preset, leveled to -14 LUFS by perceived loudness (ITU BS.1770, so a bass-heavy clip isn't
  left sounding quiet; peaks under -1 dBFS); the
  screens are committed, the sounds made at release (40 recipes would add ~25 MB to git). The front page: the poster
  as a short hero, the emulator, the manual's doors and four recipes to try. Words: nothing that sounds like bad
  design (hidden, buried), no closing period on a banner's line, no Lyra-8 in the new words (the credit line keeps it).
- 2026-11-13: **your banks by number** (Evan: "calling a G note bank A"): banks 1 to 6 (SEL + G4 .. E5), the
  Presets' two as before (P1-8, P9-16); a scene of yours named by bank and key, "3.5" (the header, banners, "→ 3.5"),
  a Preset by number, "P5". Picked over "B3-K5" and "B3-1" (B3 is a note, and the header had no room for "changed" or
  SWELL beside them) and over "3-1" (the screen's dash is a range: "1-8"). The Screen Reader says "bank 3 key 5". The
  header keeps 11 px between its sides (was 12) so "1.1 changed" fits beside DRONES and [PLAY]. Saved sounds unchanged.
- 2026-11-14: **scenes keep their latched gestures** (Evan: "it's part of the sound and really cool"): a scene saved
  with Chord latched brings Chord back. The header as it was: while the scene arrives it reads "CHORD latched", and
  "CHORD latched  1.1" once there (naming the scene first, "CHORD → 1.1", moved more of the header on every tap;
  Evan: "the previous behavior was better"). **Dreamhouse and Ashram 3 dB quieter, Tape 2 dB** (Evan: loud on
  headphones; their loud moments against P1 on headphones +1.8, -1.8, +3.3 dB before, -1.2, -4.6, +1.8 after).
  Players' saved sounds unchanged. A low cut at 12 Hz on the headphone output was tried and not taken (Evan: no low
  cut): before the output's clip it softened a saw at 8 Hz and below by 3-6 dB, and after the clip it went past full
  scale.
- 2026-11-14: **four Presets get their own Swell** (Evan: five breathing with P1's Swell, the same 23 s breath in step,
  "makes them sound too much the same"): Embers and Howl none (the bloom and the grind are their movement), Abyss a
  slow deep tide (33 s, about 18 dB), Tape a tired breath (29 s, about 7 dB); Niagara keeps it. Picked by ear from
  two options each. Their loud moments within 1.3 dB of before, so their levels stay; without dips Embers and Howl
  are 4-5 dB louder on average.
- 2026-11-14: **the flash chips by name**, as Felucca, Charles Vestal's fm1-base and fm1-x0x, and Melodee check them:
  the first FM-1s' 0x856014 and the newer ones' 0xB36014, anything else RAM only (the rescue tool the same). 0.2.1's
  rule (any standard part of 1-16 MiB) took both but named neither, so thefirmwarehub.com, which reads the chips
  from the package, listed it as "it does not check the chip". Both numbers are now in the image.
- 2026-11-14: updating from 0.2, a scene on keys 9–12 that finds no empty key 1–8 in its own bank goes on to banks 4
  and 5 (new in 0.3, so empty: 16 keys for the 12 at most), so none is left unplayed (Evan). A's go to B, C, then D,
  E; B's and C's to D and E before A or the other, since D-F are now saved before B and C: a first save cut short
  never loses a scene, and one already in D or E isn't copied twice.
