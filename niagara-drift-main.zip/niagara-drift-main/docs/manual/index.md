---
title: Manual
intro: Four ways in, by what you want to do
description: The Niagara Drift manual: start here, recipes, reference, shortcuts, help.
---

<!-- SPDX-License-Identifier: GPL-3.0-only -->

<ul class="doors">
<li><a href="recipes/sounds.md"><img class="ic" src="../../web/manual/icons/cooking-pot.svg" alt=""><small>I want a sound</small><b>Recipes</b><span>Ticks, metallic bells, warbling echoes; gestures; scenes and saving; transitions; playing live</span></a></li>
<li><a href="reference/index.md"><img class="ic" src="../../web/manual/icons/book-open.svg" alt=""><small>What does this do</small><b>Reference</b><span>Every page, knob and key, in the order of the buttons</span></a></li>
<li><a href="reference/shortcuts.md"><img class="ic" src="../../web/manual/icons/keyboard.svg" alt=""><small>Quick lookup</small><b>Shortcuts</b><span>Every key combination, hold and tap</span></a></li>
<li><a href="help.md"><img class="ic" src="../../web/manual/icons/lifebuoy.svg" alt=""><small>Stuck</small><b>Help</b><span>Installing, updating, backing up, going back to M-VAVE's firmware, problems</span></a></li>
</ul>

<!-- github -->
On GitHub these pages read as they are; on the [site](https://evanyerburgh.github.io/niagara-drift/manual/) the
recipes play their sounds.
<!-- /github -->
