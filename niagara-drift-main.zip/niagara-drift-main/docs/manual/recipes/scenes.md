---
title: Scenes and saving
intro: Keep a sound, move between sounds, and get back to where you were
description: Recipes for Niagara Drift's 48 scenes: make a preset your own, blend between two sounds by pressure, undo a scene change.
image: s-blend-0.png
---

<!-- SPDX-License-Identifier: GPL-3.0-only -->

White keys 1–8 are scenes: 6 banks of 8 (1 to 6) to fill with your own sounds, and the presets.

### Make a preset your own {#save}

*Pick a bank, change it, SAVE and a white key*

1. Tap a preset (the Presets bank: hold [[SEL]] and tap [[F5]]), then pick bank 1: hold [[SEL]] and tap [[G4]] (2 to 6 are [[A4]] to [[E5]]).
2. Change it as you like.
3. Hold [[SAVE]] and tap a white key: it's stored there ([the header](../reference/controls.md#screen-header) says 1.1). Tap that key later to glide back to it.

> **Good to know.** Presets can't be saved over: your sounds go in banks 1 to 6.


### Blend two sounds and keep a mix {#blend}

*Press a scene key harder, tap SEL*

1. Hold another scene's key and press slowly harder: the sound moves toward it, as far as you press.
2. Tap [[SEL]] while still holding: the blend stays there ("1.2 67% KEPT"). Let go when you like.

> **Good to know.** Let go without SEL and it glides back. Press all the way and hold a moment, and the scene is taken
> ("TAKEN").

![Osc, the blend kept at 67%](../media/s-blend-0.png "1.2 67% KEPT")
![Osc, after letting go](../media/s-blend-1.png "Let go: the blend stays")

**Listen** (`s-blend`)

- 0:00 1.1: P2 Embers (a darker version on 1.2)
- 0:01 1.2 pressed slowly harder
- 0:05 SEL tapped, then let go: the blend stays

### Undo a scene change {#back}

*SEL + SAVE*

1. Hold [[SEL]] and tap [[SAVE]]: back to the sound before your last scene tap or blend.
2. Again: forward to where you were.
