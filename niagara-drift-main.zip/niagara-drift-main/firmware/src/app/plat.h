/* SPDX-License-Identifier: GPL-3.0-only */
/* OMNI platform interface (from X0X's): everything the app needs from the hardware.
 *
 * The device implementation (plat_fm1.c) wraps Felucca's HAL and panel map; the
 * host implementation (host/omni_host.c) is a simulator fed by a script, which is
 * what lets the whole app — UI, sequencer, engines — run and be tested on a Mac.
 * Drawing goes through Felucca's lcd_fill / lcd_blit (lcd.c on the device, a
 * framebuffer on the host) and gfx.c on top. */
#pragma once
#include <stdint.h>

/* big zero-initialised buffers go in the .pool RAM region on the device */
#ifdef OM_HOST
#define OM_POOL
#else
#define OM_POOL __attribute__((section(".pool")))
#endif

/* panel controls, by printed label (Felucca's panel.c map turns these into matrix ids; Felucca
 * calls the second button SCL, the panel prints SEL) */
enum { B_FX, B_SEL, B_ENV, B_LFO, B_EDIT, B_GLO, B_HOME, B_SAVE, B_ARP, B_SEQ, B_PLAY, B_REC,
       B_OCTDN, B_OCTUP, NB };
enum { EN_SELECT, EN_ALGO, EN_PRESET, EN_K1, EN_K2, EN_K3, EN_K4, NE };

#define NKEYS 27                       /* F3 .. G5 */

uint32_t plat_ms(void);
uint32_t plat_us(void);                 /* microseconds, as MIDI packets are stamped (v0.3: the clock) */
uint32_t plat_buttons(void);           /* held: bit B_*; takes a look at the panel (call it first, once a round) */
uint32_t plat_keys(void);              /* held at that look: bit k = key k (0 = F3) */
int32_t plat_enc(int role);            /* detents since the last call, + = clockwise; EN_* */
uint32_t plat_master(void);            /* MASTER pot, 0..4096 gain Q12 */
int plat_pressure(uint32_t k);         /* key k's pressure 0..127 while held (0 when not), -1: it has no sensing */
void plat_leds(const uint8_t *buttons, const uint8_t *keys);   /* brightness 0..255 (as the eye sees it): [B_*], [key] */

/* USB MIDI, 4-byte USB-MIDI event packets (cable 0) */
int plat_midi_in(uint32_t *pkt, uint32_t *us);   /* 1 = got one, and when it came in, us (called from the audio ISR) */
void plat_midi_out(uint32_t pkt);      /* queue one (audio ISR or main loop) */

/* persistent storage (Felucca storage.c objects: A/B sectors, CRC, torn-write safe) */
int plat_store_load(uint32_t obj, void *dst, uint32_t max);   /* bytes loaded, < 0 = none / bad */
int plat_store_save(uint32_t obj, const void *src, uint32_t len);   /* 0 = ok; -10 held (a restore coming) */
int plat_store_held(void);             /* 1: a restore from USB is staged, saves wait (it restarts after) */
#define PLAT_STORE_MAX 3840u           /* bytes per object */
enum { OBJ_PROJ, OBJ_PANEL, OBJ_BANKB, OBJ_BANKC, OBJ_BANKP, OBJ_BANKD, OBJ_BANKE, OBJ_BANKF, OBJ_NOBJ };
/* flash: OBJ_PROJ 0xFC000, OBJ_PANEL 0xDC000, OBJ_BANKB 0x97000, OBJ_BANKC 0x99000, OBJ_BANKP 0x9B000 (the Presets
 * saved over), OBJ_BANKD 0x9D000, OBJ_BANKE 0xDE000, OBJ_BANKF 0x9F000 and 0xFE000 (its two copies apart, as
 * Felucca's FM6 bank); 2 sectors each, inside
 * Felucca's data areas; our installer writes only 0x4000..0x93000 and 0xE0000..0xE5000) */

/* audio load in % of the render budget, and xruns since boot (device: from the ISR) */
int plat_headphones(void);              /* 1: headphones in (the speaker off) */
uint32_t plat_cpu_pct(void);
uint32_t plat_xruns(void);
